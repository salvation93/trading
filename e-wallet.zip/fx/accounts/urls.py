from django.urls import path

from . import views

app_name = 'accounts'

urlpatterns = [
    path('sign_in/', views.sign_in, name='sign_in'),
    path('sign_up/', views.sign_up, name='sign_up'),
    # path('admin_login/', views.admin_login, name = 'admin_login'),
    path('dash_admin/', views.dash_admin, name = 'dash_admin'),
    path('admin_edit_profile/', views.admin_edit_profile, name = 'admin_edit_profile'),
    path('sign_out/', views.sign_out, name='sign_out'),
    path('profile/', views.profile, name='profile'),
    path('menu/', views.menu, name = 'menu'),
    path('withdraw_to_bank/', views.withdraw_to_bank, name = 'withdraw_to_bank'),
    path('bitcoins/', views.bitcoins, name = 'bitcoins'),
    path('edit_profile/', views.edit_profile, name='edit_profile'),
    path('change_password/', views.change_password, name='change_password'),
    
]
