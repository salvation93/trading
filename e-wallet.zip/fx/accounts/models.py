from django.contrib.auth.models import User
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver


# Create your models here.
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=255, default='')
    last_name = models.CharField(max_length=255, default='')
    email = models.EmailField(default='mail@email.com')
    balance = models.IntegerField(default='000', null=True)

    def __str__(self):
        return self.user.username


def create_profile(sender, **kwargs):
    if kwargs['created']:
        profile = Profile.objects.create(user=kwargs['instance'])

post_save.connect(create_profile, sender=User)

# class Administration(models.Model):
#    email = models.EmailField(default='mail@email.com')
#    password1 = models.CharField(max_length=10, null=True)
#    password2 = models.CharField(max_length=10, null=True)