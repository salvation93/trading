from django.shortcuts import render
from django.contrib.auth.decorators import login_required

def home(request):
    return render(request, 'index.html')
    
def contact(request):
    return render(request, 'contact.html')

def about(request):
    return render(request, 'about.html')

def terms(request):
    return render(request, 'terms.html')

@login_required
def deposit(request):
    return render(request, 'pay.html')
    